/*************************************************************************
 * Program Name: activityMain.cpp
 * Author: Brittany Dunn
 * Date: Feb 3 2019
 *************************************************************************/
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include "DoublyList.hpp"
#include "Node.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::string;
using std::vector;

bool compareStart(Node* left, Node* right){
    return (left->start > right->start);
}


int main(){
   
    string fileName = "act.txt";
    ifstream readFile;
    int number;
    int size = 0;
    //Vector to store numbers from file
    vector<int> myVect;

    //Open file
    readFile.open(fileName, std::ios::in);
	
    //If file cannot be opened exit program
    if(!readFile){
	cout << "Error opening file." << endl;;
	return 0;
    }

    else{
	while(readFile >> number){
		//Add number to vector
		myVect.push_back(number);
		//Increase size for each number from the file
		++size;
	    }
    }
	
    //Close file
    readFile.close();
    
    //Use to go through vector starting at 0
    int v = 0;
    
    //Use to keep track of the set
    int setNumber = 1;
    
   do{
	
	//Get the number of activities
	int totalActs = myVect[v];
	v++;
	
	//Create an array the size of the total number of activities
	Node* allActs[totalActs];
	
	//Create a node for each activity using a loop
	for(int i = 0; i < totalActs; i++){
	    //Get activity, start, and finish from vector
	    int activity = myVect[v];
	    ++v;
	    int start = myVect[v];
	    ++v;
	    int finish = myVect[v];
	    ++v;
	    
	    //Create new node and store in array
	    allActs[i] = new Node(activity,start,finish,nullptr,nullptr);
	}
	
	//Sort the activities by their start time in descending order
	std::sort(allActs, allActs + totalActs, compareStart);
	
	//Create a linked list to hold the selected activites
	DoublyList selected;
	
	//Track number of selected activities
	int numberOfActs = 0;
	
	//Check each activity to see if it can be selected
	for(int i = 0; i < totalActs; i++){
	    //Check if selected acts is currently empty
	    if(selected.head == nullptr){
		//If so add the node with the latest start time
		selected.addHeadNode(allActs[i]->activity,allActs[i]->start,allActs[i]->finish);
		//Increase count
		++numberOfActs;
	    }
	    //If the finish time of the current (latest start time) activity is less than or 
	    //equal to the start time of the tail of the selected activities
	    if(allActs[i]->finish <= selected.tail->start){
		//Then add the current activity to the selected list
		selected.addTailNode(allActs[i]->activity,allActs[i]->start,allActs[i]->finish);
		//Increase count
		++numberOfActs;
	    }
	    //If not then the activity is not selected and we move to the next activity with the latest start time
	}
	
	//Output the results to the console
	selected.traverseReverse(setNumber,numberOfActs);
	
	//Increase set number
	++setNumber;
	
    }while(v < size);
	
    return 0;

}