/*************************************************************************
 * Program Name: Node.hpp
 * Author: Brittany Dunn
 * Date: May 13 2018 Modified: Feb 17 2019
 * Modified from code created for CS 162
 * Description: This is the header file for the class Node
 *************************************************************************/

#ifndef NODE_HPP
#define NODE_HPP

#include <string>
#include <iostream>

struct Node
{
	std::string name;
	Node *next;
	Node *prev;
	Node(std::string, Node*, Node*);
};

#endif
