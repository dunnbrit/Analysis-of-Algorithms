/*************************************************************************
 * Program Name: wrestler.cpp
 * Author: Brittany Dunn
 * Date: Feb 17 2019
 *************************************************************************/
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include "DoublyList.hpp"
#include "Node.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::string;
using std::vector;


int main(){
   
    string fileName;
    ifstream readFile;
    string word;
    int size = 0;
    //Vector to store numbers from file
    vector<string> myVect;
    
    //Prompt user for file name
    cout << "Please enter the name of your file." <<endl;

    //Get file name
    cin >> fileName;
    cin.ignore(100,'\n');


    //Open file
    readFile.open(fileName, std::ios::in);
	
    //If file cannot be opened exit program
    if(!readFile){
	cout << "Error opening file." << endl;;
	return 0;
    }

    else{
	while(readFile >> word){
		//Add number to vector
		myVect.push_back(word);
		//Increase size for each number from the file
		++size;
	    }
    }
	
    //Close file
    readFile.close();
    
    
    //Use index to track spot within myVect
    int index = 0;
    
    //Get total number of wrestlers
    int totalWrestlers = stoi(myVect[index]);
    //Increase index
    ++index;    
    
    //Create an array that is the size of the number of wrestlers
    string wrestlers[totalWrestlers];
    
    
    //Add each wrestler to the array
    for(int i = 0; i < totalWrestlers; i++){
	//Add the wrestler to array
	wrestlers[i] = myVect[index];
	//Increase Index
	++index;
    }
    
    //Create a list for babyFaces and heels
    DoublyList heels;
    DoublyList babyFaces;  
    
    //Create an array for the unassigned pairs
    vector<string> unassigned;
    //use to track size of vector
    int vectorSize = 0;
    
    //Get the number of rivalries 
    int rivalries = stoi(myVect[index]);
    //Increase index
    index++;
    
    //Add the first wrestler to baby face
    babyFaces.addHeadNode(wrestlers[0]);
    
    //For each rivalry check if either rival belongs to either group
    //if one belongs to a group make sure the other can be added to the opposite
    //group and add it if possible
    for(int i = 0; i < rivalries; ++i){
	
	//Use to store rival1
	string rival1 = myVect[index];
	//Increase index
	++index;
	
	//Use to store rival2
	string rival2 = myVect[index];
	//Increase index
	++index;

	//Check if rival1 is in babyfaces
	if(babyFaces.contains(rival1)){
	    //If rival1 is in babyface, check if rival2 is also in babyFaces
	  
	    //If rival2 is in babyFaces
	    if(babyFaces.contains(rival2)){
		//Then this is not a valid pair, so it is impossible
		cout << "IMPOSSIBLE" << endl;
		return 0;
	    }
	    //If rival2 is not in babyFaces
	    else{
		//Check if rival2 is already in heels
		if(heels.contains(rival2)== false){
		   //If rival2 is not in heels then add it
		    heels.addTailNode(rival2);
		}
		//If rival2 is already in heels do nothing
	    }   
	}
	//Check if rival2 is in babyFaces
	
	
	else if(babyFaces.contains(rival2)){
	    //If rival2 is in babyface, check if rival1 is also in babyFaces
	  
	    //If rival1 is in babyFaces
	    if(babyFaces.contains(rival1)){
		//Then this is not a valid pair, so it is impossible
		cout << "IMPOSSIBLE" << endl;
		return 0;
	    }
	    //If rival1 is not in babyFaces
	    else{
		//Check if rival1 is already in heels
		if(heels.contains(rival1)== false){
		   //If rival1 is not in heels then add it
		    heels.addTailNode(rival1);
		}
		//If rival1 is already in heels do nothing
	    }   
	}

	//Check if rival1 is in heels
	else if(heels.contains(rival1)){
	    //If rival1 is in heels, check if rival2 is also in heels
	  
	    //If rival2 is in heels
	    if(heels.contains(rival2)){
		//Then this is not a valid pair, so it is impossible
		cout << "IMPOSSIBLE" << endl;
		return 0;
	    }
	    //If rival2 is not in heels
	    else{
		//Check if rival2 is already in babyfaces
		if(babyFaces.contains(rival2)== false){
		   //If rival2 is not in babyFaces then add it
		    babyFaces.addTailNode(rival2);
		}
		//If rival2 is already in babyFaces do nothing
	    }   
	}
	//Check if rival2 is in heels
	else if(heels.contains(rival2)){
	    //If rival2 is in heels, check if rival1 is also in heels
	  
	    //If rival1 is in heels
	    if(heels.contains(rival1)){
		//Then this is not a valid pair, so it is impossible
		cout << "IMPOSSIBLE" << endl;
		return 0;
	    }
	    //If rival1 is not in heels
	    else{
		//Check if rival1 is already in babyFaces
		if(babyFaces.contains(rival1)== false){
		   //If rival1 is not in babyFaces then add it
		    babyFaces.addTailNode(rival1);
		}
		//If rival1 is already in babyFaces do nothing
	    }   
	}
	//If neither rival have been assigned, add to unassigned
	else{
	    unassigned.push_back(rival1);
	    vectorSize++;
	    unassigned.push_back(rival2);
	    vectorSize++;
	}

    }
    
    //Check if there are any unassigned pairs left
    if(vectorSize > 0){
	//For each pair left
	for(int i = 0; i < vectorSize; i++){
	    //Check if either rivals are within babyfaces or heels
	    string rival1 = unassigned[i];
	    ++i;
	    string rival2 = unassigned[i];
	    
	    //Set both to 0 to represent no assignment
	    int rival1Assign = 0;
	    int rival2Assign = 0;
	
	    if(babyFaces.contains(rival1)){
		//Add 1 to represent babyface
		rival1Assign += 1;
	    } 
	    if(babyFaces.contains(rival2)){
		//Add 1 to represent babyface
		rival2Assign += 1;
	    }
	    if(heels.contains(rival1)){
		//Add 2 to represent heels
		rival1Assign += 2;
	    }
	    if(heels.contains(rival2)){
		//Add 2 to represent heels
		rival2Assign += 2;
	    }
	    
	    //If either have an assign of 3 or greater then not possible
	    if(rival1Assign >=3 || rival2Assign >=3){
		cout << "IMPOSSIBLE" << endl;
		return 0;
	    }
	    //If both are part of the same group then no possible
	    if(rival1Assign == 1 && rival2Assign == 1){
		cout << "IMPOSSIBLE" << endl;
		return 0;
	    }
	    if(rival1Assign == 2 && rival2Assign == 2){
		cout << "IMPOSSIBLE" << endl;
		return 0;
	    }
	    //If both equal 0 then assign them each to a different group
	    if(rival1Assign == 0 && rival2Assign == 0){
		babyFaces.addTailNode(rival1);
		heels.addTailNode(rival2);
	    }
	    
	}
	
    }
    
    cout << "Yes Possible" << endl;
    cout << "Babyfaces: ";
    babyFaces.printList();
    cout << "Heels: ";
    heels.printList();
	
    return 0;

}