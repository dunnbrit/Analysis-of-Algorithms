/*************************************************************************
 * Program Name: DoublyList.hpp
 * Author: Brittany Dunn
 * Date: May 13 2018 Modified: Feb 17 2019
 * Modified from code created for CS 162
 * Description: This is the header file for the class DoublyList
 *************************************************************************/

#ifndef DOUBLYLIST_HPP
#define DOUBLYLIST_HPP

#include "Node.hpp"

class DoublyList
{
	public:  
	Node *head;
	Node *tail;
	
	DoublyList();
	
	~DoublyList();

	void addHeadNode(std::string);

	void addTailNode(std::string);

	void deleteFirstNode();

	void deleteLastNode();

	void traverseReverse();

	void printList();

	void printHeadNode();
	
	void printTailNode();
	
	bool contains(std::string);

};

#endif	
