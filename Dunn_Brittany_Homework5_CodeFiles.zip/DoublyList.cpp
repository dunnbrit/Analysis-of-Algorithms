/*************************************************************************
 * Program Name: DoublyList.cpp
 * Author: Brittany Dunn
 * Date: May 13 2018 Modified: Feb 17 2019
 * Modified from code created for CS 162
 * Description: This is the implementation file for the class DoublyList
 *************************************************************************/

#include "DoublyList.hpp"
#include "Node.hpp"
#include <iostream>

using std::cout;
using std::endl;

//This is the constructor for DoublyList
DoublyList::DoublyList()
{
	head = nullptr;
	tail = nullptr;
}

//This is the destructor for DoublyList
DoublyList::~DoublyList()
{
	Node *nodePtr = head;
	while(nodePtr != nullptr)
	{
		Node *deleteIt = nodePtr;
		nodePtr = nodePtr->next;
		delete deleteIt;
	}
}

//This function prints the doubly list
void DoublyList::printList()
{
	//If list is empty
	if(head == nullptr)
	{
		cout << "\nYour linked list is currently empty." <<endl;
	}
	//If list has one node
	else if(head == tail)
	{
		cout << head->name << endl;
	}
	//Print list until the end
	else
	{
		Node *nodePtr = head;
		while(nodePtr != nullptr)
		{
			cout << nodePtr->name << " ";
			nodePtr = nodePtr->next;
		}
		cout << " " <<endl;
	} 
}

//This function adds a new node to the head of the list
void DoublyList::addHeadNode(std::string n)
{
	std::string name = n;

	//If list is empty set prev and next to head ptr
	if(head == nullptr)
	{
		head = new Node(name,head,head);
		tail = head;	
	}
	//If list is not empty make a new node and add it as the head of list
	else
	{
		Node *nodePtr = head;
		head = new Node(name, head,nodePtr);
		nodePtr->prev = head;
		//If node is pointing to itself as next change next to 
		//nullptr (node was previously head)	
		if(nodePtr->next == nodePtr)
		{
			nodePtr->next = nullptr;
		}
	}
		
}

//This function adds a new node to the tail of the list
void DoublyList::addTailNode(std::string n)
{
	std::string name = n;

	//If list is empty set prev and next to head ptr
	if(head == nullptr)
	{
		head = new Node(name,head,head);
		tail = head;
	}
	//If list is not empty make a new node and add it as the tail of list
	else
	{
		Node *nodePtr = tail;
		tail = new Node(name, nodePtr, nullptr);
		nodePtr->next = tail;	
	}
}

//This function deletes the first node of the list
void DoublyList::deleteFirstNode()
{
	//If list is empty print warning
	if(head == nullptr)
	{
		cout << "\nLinked list is empty. Cannot proceed." <<endl;
	}
	//If not delete first node
	else
	{
		Node *nodePtr = head;
		//If list has only one node, set head and tail to null
		if(head->next == head)
		{
			head = nullptr;
			tail = nullptr;
		}
		//If not then make next node head
		else
		{
			head = nodePtr->next;
			head->prev = head;
			//If there will only be one node after delete then 
			//change node next to point to itself instead of null
			if(head->next == nullptr)
			{
				head->next = head;
			}
		}
		//Delete previous head node
		delete nodePtr;
	}
}
		
//This function deletes the last node of the list
void DoublyList::deleteLastNode()
{
	//If list is empty print warning
	if(tail == nullptr)
	{
		cout << "\nLinked list is empty. Cannot proceed." <<endl;
	}
	//If not delete last node
	else
	{
		Node *nodePtr = tail;
		//If list has only one node, set head and tail to null
		if(tail->next == tail)
		{
			head = nullptr;
			tail = nullptr;
		}
		//If not make previous node tail
		else
		{
			tail = nodePtr->prev;
			//If there will be only one node after delete then make
			//node point to itself for next 
			if(head == tail)
			{
				tail->next = tail;
			}
			//If not then have tail node point next to null
			else
			{
				tail->next = nullptr;
			}
		}
	}
}

//This function prints the list from tail to head
void DoublyList::traverseReverse()
{
	
	
	//If list is empty
	if(head == nullptr)
	{
		cout << "Names: none" <<endl;
	}
	//If list has one node
	else if(head == tail)
	{
		cout << "Names: ";
		cout << head->name << endl;
	}
	//Print list in reverse
	else
	{
		cout << "Names: ";
		Node *nodePtr = tail;
		while(nodePtr != head)
		{
			cout << nodePtr->name << " ";
			nodePtr = nodePtr->prev;
		}
		cout << head->name << " " <<endl;
	}
	
	cout << endl;
}

//This function prints the value of the head node
void DoublyList::printHeadNode()
{
	cout << "The value of the Node head is pointing to is: ";
	if(head == nullptr)
	{
		cout << "nullptr" <<endl;
	}
	else
	{
		cout << head->name <<endl;	
	}
}

//This function prints the value of the tail node
void DoublyList::printTailNode()
{
	cout << "The value of the Node tail is pointing to is: ";
	if(tail == nullptr)
	{
		cout << "nullptr" <<endl;
	}
	else
	{
		cout << tail->name <<endl;
	}
}

//This functions return true or false if a wrestler's name is within a list
bool DoublyList::contains(std::string n){
    std::string name = n;
    
	//If list is empty
	if(head == nullptr)
	{
	    return false;
	}
	//If list has one node
	else if(head == tail)
	{
	    if(head->name == name){
		return true;
	    }
	    else{
		return false;
	    }
	}
	else
	{
		Node *nodePtr = tail;
		while(nodePtr != head)
		{
		    if(nodePtr->name == name){
			return true;
		    }	
		    else{
			nodePtr = nodePtr->prev;
		    }
		}
		if(nodePtr->name == name){
		    return true;
		}
		return false;
	}
}
