/*************************************************************************
 * Program Name: Node.hpp
 * Author: Brittany Dunn
 * Date: May 13 2018 Modified: Feb 17 2019
 * Modified from code created for CS 162
 * Description: This is the implementation file for the class Node
 *************************************************************************/

#include "Node.hpp"

//This is the constructor for node
Node::Node(std::string n, Node* prev1 = nullptr, Node* next1 = nullptr)
{
	name = n;
	prev = prev1;
	next = next1;
}
