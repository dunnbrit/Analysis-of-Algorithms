/*************************************************************************
 * Program Name: binpack.cpp
 * Author: Brittany Dunn
 * Date: March 10 2019
 *************************************************************************/
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::string;
using std::vector;

//First Fit Function
int firstFit(int *items, int capacity, int numberOfItems){
    //Create a vector to use for the bins
    vector<int> firstFitBins;
    
    //Set the first bin to the max capacity
    firstFitBins.push_back(capacity);
    
    //For each item put it in the first bin it fits
    for(int i = 0; i < numberOfItems; i++){
	//Use added to track if the item has been added to a bin
	bool added = 0;
	//Use bin to track the which bin is being checked for the item to add to
	int bin = 0;
	
	//While the item has not been added to a bin
	while(added == 0){
	    //Check if the current bin has been created yet
	    if(bin < firstFitBins.size()){
		//If the bin has been created, check if it can fit the item
		if(items[i] <= firstFitBins[bin]){
		    //If it does fit then add it to the bin by subtracting its weight
		    firstFitBins[bin] -= items[i];
		    //Set added to true
		    added = 1;
		}
		//If it does not fit, move to next bin
		else{
		    //Next bin
		    bin++;
		}
	    }
	    //If bin has not been created
	    else{
		//Create a new bin with the max capacity
		firstFitBins.push_back(capacity);
		//Add item to bin by subtracting its weight
		firstFitBins[bin] -= items[i];
		//Set added to true
		added = 1;
	    }
	}	
    }
    //Return size of firstFitBins which is equal to the bins used
    return firstFitBins.size();
}

//Best Fit Function
int bestFit(int *items, int capacity, int numberOfItems){ 
    //Create a vector to use for the bins
    vector<int> bestFitBins;
    
    //Set the first bin to the max capacity
    bestFitBins.push_back(capacity);
    
    //For each item put it in the bin that would leave the least amount of room
    for(int i = 0; i < numberOfItems; i++){
	//Variable to track the room left in a bin if the item was added
	int left = -1;
	//Variable to track the bin which would leave the least room
	int selectedBin = -1;
	
	//For each bin find the amount of room left if item were added
	for(int b = 0; b < bestFitBins.size(); b++){
	    //If no bin has been selected yet
	    if(selectedBin == -1){
		//Then check if the current bin has space for the item
		if(items[i] <= bestFitBins[b]){
		    //If there is room then make it the selected bin
		    selectedBin = b; 
		    //Update room left to this bin current capacity minus item weight
		    left = bestFitBins[b] - items[i];
		}
		//Otherwise move to next bin
	    }
	    //If a bin has already been selected
	    else{
		//Check if there would be less room left in the current bin if 
		//the item was added than in the selected bin
		if(bestFitBins[b] - items[i] < left && bestFitBins[b] - items[i] >= 0){
		    //If there would be less room change this to selected bin
		    selectedBin = b;
		    //Update left
		    left = bestFitBins[b] - items[i];
		}
		//Otherwise move to next bin
	    }
	}
	//Once the bin with the least room left is found
	//If there was not a bin with enough room for the item
	
	if(selectedBin == -1){
	    //Add a new bin 
	    bestFitBins.push_back(capacity);
	    //Use the new bin for that item
	    bestFitBins.back() -= items[i];
	}
	//If there was a bin with the least room left
	else{
	    //Add the item to the selected bin
	    bestFitBins[selectedBin] -= items[i];
	}
    }
    //Return size of bestFitBins which is equal to the bins used
    return bestFitBins.size();
}


int main(){
   
    string fileName = "bin.txt";
    ifstream readFile;
    int number;
    int size = 0;
    //Vector to store numbers from file
    vector<int> myVect;

    //Open file
    readFile.open(fileName, std::ios::in);
	
    //If file cannot be opened exit program
    if(!readFile){
	cout << "Error opening file." << endl;;
	return 0;
    }

    else{
	while(readFile >> number){
		//Add number to vector
		myVect.push_back(number);
		//Increase size for each number from the file
		++size;
	    }
    }
	
    //Close file
    readFile.close();
    
    //Use to go through vector starting at 0
    int v = 0;
    
    //Get number of test cases
    int testCases = myVect[v];
    v++;
    
    //For each test cases
    for(int i = 0; i < testCases; i++){
	//Get the capacity of the bins
	int capacity = myVect[v];
	v++;
	
	//Get the number of items
	int numberOfItems = myVect[v];
	v++;
	
	//Create an array to hold the weight of each item
	int items[numberOfItems];
	
	//Add each items weight to the array items
	for(int i = 0; i < numberOfItems; i++){
	    items[i] = myVect[v];
	    v++;
	}
	
	//Call first fit function and store return value as the number of bins 
	//used for first fit bin packing
	int totalFirstFit = firstFit(items, capacity, numberOfItems);
	
	//Call best fit function and store return value as the number of bins 
	//used for best fit bin packing
	int totalBestFit = bestFit(items, capacity, numberOfItems);
	
	//Sort the items array
	std::sort(items, items + numberOfItems, std::greater<int>());
	//Call first fit function and store return value as the number of
	//bins used for first fit decreasing bin packing
	int totalFirstFitDecreasing = firstFit(items, capacity, numberOfItems);
	
	
	//Print results
	cout << "Test Case " << i+1 << " First Fit: " << totalFirstFit ;
	cout << " First Fit Decreasing: " << totalFirstFitDecreasing;
	cout << " Best Fit: " << totalBestFit << endl;
    }
    



	
    return 0;

}